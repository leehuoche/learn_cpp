#include<iostream>
using namespace std;


int main() {
	cout << "Hello world" << endl;
	cout << "Welcome to C++" << endl;
	return 0;
}
