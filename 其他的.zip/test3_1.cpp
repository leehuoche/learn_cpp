#include <iostream>
using namespace std;
int main(){
	int n=5;
	while(n){
		n--;
		cout<<n<<" ";
		
	}
	return 0;
}
